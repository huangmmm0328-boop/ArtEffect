const styles=[
{name:'Q版现代卡通射击',en:'CARTOON SHOOTER',desc:'小角色，大火力。用高密度特效点燃战场。',tags:['现代战场','高密度特效'],games:[0],color:'#e9aa64',features:['Q版人物与现代武器形成直接的题材识别。','低干扰的战场色彩，为火焰、冰冻与激光留出视觉空间。','通过敌群密度和范围伤害，建立可直观看懂的成长反馈。'],focus:'简单角色造型与高密度技能特效的结合。',vfx:'枪械射击 · 爆炸冲击 · 冰冻 · 激光 · 电击'},
{name:'Q萌卡通塔防',en:'CUTE TOWER DEFENSE',desc:'圆润造型与鲜明色彩，让策略更有亲和力。',tags:['萌系角色','英雄进化'],games:[1],color:'#a4a5f1',features:['圆润轮廓弱化战斗题材的距离感。','角色通过配色、体型和武器保持辨识度。','召唤与进化是值得单独观察的视觉节点。'],focus:'角色辨识度与技能表现之间的关系。',vfx:'英雄召唤 · 技能释放 · 范围攻击 · BOSS攻击 · 进化'},
{name:'2D植物拟人卡通',en:'2D PLANT CARTOON',desc:'用植物符号、卡通轮廓与角色格位建立识别。',tags:['2D卡通','植物拟人'],games:[2],color:'#c6d67c',features:['植物器官和明快配色帮助角色在小尺寸下被识别。','角色格位、底部角色池与合成界面组织操作信息。','当前采集版本包含联动角色，不据此判断模型面数或制作成本。'],focus:'植物符号、卡通角色与合成界面怎样共同降低理解成本。',vfx:'植物攻击 · 龙形能量 · 范围反馈'},
{name:'Q萌东方仙侠',en:'ORIENTAL FANTASY',desc:'把东方想象，装进轻盈明快的仙侠世界。',tags:['国风卡通','法宝灵兽'],games:[3,4],color:'#80d4d3',features:['以Q版比例降低仙侠题材的理解门槛。','法宝、符箓和灵兽承担身份识别。','场景的留白与法术的高亮形成视觉层次。'],focus:'传统东方文化与轻量化技能特效的融合。',vfx:'雷电法术 · 剑阵 · 符箓 · 灵兽召唤 · 能量爆发'},
{name:'中式微恐探险',en:'FOLK HORROR',desc:'灯火、符咒与迷雾，让民俗成为氛围语言。',tags:['民俗志怪','氛围光影'],games:[5],color:'#d59185',features:['民俗物件比复杂造型更容易传递题材。','暗色场景中，暖色灯火和符咒成为视线锚点。','烟雾、光影和声音需要结合动态素材评估。'],focus:'如何利用环境、光影和符咒形成独特的视觉氛围。',vfx:'符箓攻击 · 法术释放 · 桃木剑 · BOSS技能 · 驱邪'},
{name:'国风横屏武侠',en:'ENSEMBLE WUXIA',desc:'横向角色队列、彩色宫殿与群体招式，共同组织武侠战场。',tags:['国风角色','横屏群战'],games:[6],color:'#c6c6be',features:['角色队列和BOSS体型构成横屏战斗的视觉重心。','斩击、飞剑与恢复光环承担不同的反馈信息。','彩色建筑、角色和技能需要保持足够明度差异。'],focus:'横屏武侠中，角色队列、背景与招式轨迹如何分层。',vfx:'飞剑 · 斩击 · 恢复光环 · 群体反馈'}];
const games=[
{name:'向僵尸开炮',style:0,type:'射击 / Roguelike',source:'https://www.taptap.cn/app/583688',sourceName:'TapTap · 开发者游戏介绍',official:'https://xjskp.scgame.com.cn/'},
{name:'永远的蔚蓝星球',style:1,type:'塔防'},
{name:'保卫向日葵',style:2,type:'植物题材 / 塔防'},
{name:'造化仙府',style:3,type:'东方仙侠'},
{name:'灵画师',style:3,type:'东方仙侠'},
{name:'镇邪人',style:4,type:'民俗探险'},
{name:'武侠大明星',style:5,type:'武侠动作'},
{name:'疯狂水世界',style:-1,type:'模拟 / 生存',ref:true,storeId:'790816',visualLabel:'漫画联动与生存题材',source:'https://www.taptap.cn/app/790816'},
{name:'三国：冰河时代',style:-1,type:'策略 / 经营 / SLG',ref:true,storeId:'748248',visualLabel:'冰雪三国策略',source:'https://www.taptap.cn/app/748248'},
{name:'羊了个羊',style:-1,type:'休闲 / 益智',ref:true,storeId:'238441',visualLabel:'简约卡通益智',source:'https://www.taptap.cn/app/238441'}];
const effects=[
{name:'爆炸冲击',en:'EXPLOSION',icon:'✷',art:0,game:0,desc:'从爆心到冲击边缘，以体积和扩散传递范围伤害。',motion:'起手蓄能 → 瞬间爆发 → 冲击扩散 → 残留消散',take:'范围越大，越需要清晰的伤害边界。',tags:['爆炸','冲击波','范围伤害']},
{name:'元素技能',en:'ELEMENTAL',icon:'ϟ',art:3,game:3,desc:'以色彩、纹理和运动方式区分火焰、冰冻与雷电。',motion:'前摇提示 → 元素成形 → 命中反馈 → 状态残留',take:'让玩家先看懂元素，再感受到威力。',tags:['火焰','冰冻','雷电']},
{name:'剑气攻击',en:'SWORD ENERGY',icon:'⌁',art:5,game:6,desc:'用弧线、拖尾与墨迹强化出招方向和速度感。',motion:'蓄势 → 斩击轨迹 → 接触停顿 → 剑气消散',take:'清晰的运动轨迹，比堆叠亮光更能表现招式。',tags:['斩击','剑气','拖尾']},
{name:'召唤特效',en:'SUMMONING',icon:'◇',art:1,game:1,desc:'通过聚光、轮廓展开和色彩变化强调新角色登场。',motion:'区域预告 → 能量汇聚 → 角色显现 → 光效收束',take:'把召唤做成一个值得期待的登场瞬间。',tags:['召唤','变身','进化']},
{name:'范围攻击',en:'AREA OF EFFECT',icon:'◎',art:2,game:2,desc:'以法阵、光环与地面标记，让群体攻击范围一眼可见。',motion:'范围提示 → 能量积聚 → 群体命中 → 地面残留',take:'先传达边界，再传达伤害强度。',tags:['法阵','光环','群体攻击']},
{name:'氛围特效',en:'ATMOSPHERIC',icon:'♧',art:4,game:5,desc:'符咒、烟雾与局部光源共同构成神秘的场景层次。',motion:'低频环境循环 → 事件触发 → 符咒亮起 → 回归静态',take:'控制特效的频率，让安静也成为表现的一部分。',tags:['符咒','烟雾','灵异效果']}];
const trends=[{title:'卡通角色与轮廓辨识',en:'CHARACTER READABILITY',desc:'观察不同题材的角色在小屏幕中如何被识别。',cases:'向僵尸开炮、永远的蔚蓝星球',visual:'人物比例、武器外形、服装与配色。',cost:'尚无团队制作成本数据，先通过样片比较不同细节投入的收益。',prediction:'角色品质可能成为差异点，轻量化渲染仍是平台适配的关键。'},
{title:'东方题材的风格分化',en:'ORIENTAL VARIATIONS',desc:'对照浅色修仙、暗色民俗与彩色武侠的画面差异。',cases:'造化仙府、灵画师、镇邪人、武侠大明星',visual:'Q版比例、东方符号、场景明度与配色。',cost:'纹样、建筑和法术语言可作为复用方向，实际效率需记录工时验证。',prediction:'题材符号与现代卡通语言的结合，有机会产生更鲜明的风格定位。'},
{title:'战斗反馈与可读性',en:'COMBAT READABILITY',desc:'观察技能范围、运动轨迹与命中反馈是否清晰。',cases:'向僵尸开炮、武侠大明星',visual:'技能轮廓、运动拖尾、连击节奏与受击反馈。',cost:'优先比较高频攻击与核心技能的样片表现，同时记录运行性能。',prediction:'技能的可读性和打击反馈可能比单纯增加特效数量更有价值。'},
{title:'视觉规则与资源复用',en:'VISUAL CONSISTENCY',desc:'先观察哪些规则可复用，再以团队工时验证效率。',cases:'保卫向日葵、造化仙府',visual:'角色格位、界面模块、色彩分区与效果模板。',cost:'尚无实际制作工时或成本数据，不能由截图断言低成本。',prediction:'统一角色尺寸、界面模块和效果规范可能减少维护工作；实际收益需要在样片制作中记录工时验证。'}];
