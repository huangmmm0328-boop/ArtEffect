/* GitHub Pages release: local catalogue + independently dated ranking snapshots. */
const pagesArchiveEntries = discoveryCurated;
discoveryCurated = function () {
  const archives = pagesArchiveEntries();
  const stores = games.filter(g => g.storeId).map(g => ({
    ...window.COMPARISON_STORE_DATA[g.storeId], detailLoaded: true
  })).filter(g => g.id);
  return [...archives, ...stores];
};
const pagesHomeSearchPanel = homeSearchPanel;
homeSearchPanel = function () {
  return pagesHomeSearchPanel()
    .replace('联网搜游戏 ↗', '搜索资料')
    .replace('输入游戏名称，如 羊了个羊、王者荣耀…', '搜索已收录游戏，如 向僵尸开炮、羊了个羊…')
    .replace('公开游戏库 · 同名请核对发行方', '本库 10 款案例 · 可前往商店搜索更多游戏')
    .replace('搜索即可浏览应用商店的介绍与宣传资料；原有 7 款保留完整美术研究档案。', '搜索本库 10 款游戏，浏览美术档案、真实 GIF 与商店宣传资料；更多游戏可打开商店搜索。');
};
searchDiscovery = async function (query) {
  const q = String(query || '').trim();
  discoverySequence++;
  const all = discoveryCurated();
  const list = q ? all.filter(e => [e.title, e.developer, ...(e.tags || [])].join(' ').toLowerCase().includes(q.toLowerCase())) : all;
  for (const entry of list) discoveryEntries.set(entry.id, entry);
  renderDiscoveryResults(list);
  discoveryStatus(q ? `本库找到 ${list.length} 款游戏。商店最新资料请以原发布页为准。` : '本库 10 款游戏均可打开；点击游戏查看图片与资料。');
  if (q) {
    const link = document.createElement('a');
    link.className = 'button';
    link.href = 'https://www.taptap.cn/search/' + encodeURIComponent(q) + '?type=app';
    link.target = '_blank'; link.rel = 'noopener noreferrer';
    link.textContent = `到 TapTap 搜索“${q}” ↗`;
    document.querySelector('#discovery-results').append(link);
  }
};
const pagesSetupHomeSearch = setupHomeSearch;
setupHomeSearch = function () {
  pagesSetupHomeSearch();
  searchDiscovery('');
};
const pagesFetchDetails = fetchDiscoveryDetails;
fetchDiscoveryDetails = async function (entry) {
  if (entry.index !== undefined || entry.detailLoaded) return entry;
  const saved = window.COMPARISON_STORE_DATA?.[entry.id];
  if (saved) { Object.assign(entry, saved, {detailLoaded:true}); return entry; }
  entry.loadError = '此游戏暂未收录。请打开原发布页查看最新介绍与宣传资料。';
  throw Error(entry.loadError);
};
const pagesPaintRankings = paintRankings;
paintRankings = function () {
  pagesPaintRankings();
  const state = document.querySelector('#ranking-state');
  if (!state || !rankingData) return;
  state.textContent = rankingData.updateStatus === 'failed' ? '本轮更新未成功 · 保留原快照' : '定时采集快照 · 非实时排名';
  state.classList.toggle('stale', rankingData.updateStatus === 'failed');
};
refreshRankings = async function () {
  if (!document.querySelector('#ranking-results')) return;
  const button = document.querySelector('#ranking-refresh');
  button.disabled = true; button.textContent = '检查最新快照…';
  try {
    const response = await fetch(new URL('data/rankings.json', location.href), {cache:'no-store', signal:AbortSignal.timeout(15000)});
    if (!response.ok) throw Error('unavailable');
    const data = await response.json();
    if (!data.boards?.length || !Number.isFinite(Date.parse(data.fetchedAt))) throw Error('invalid');
    rankingData = {...data, stale:true}; rankingLastFetch = Date.now();
    paintRankings();
    document.querySelector('#ranking-error').textContent = data.updateStatus === 'failed'
      ? '本轮未能连接来源，保留原获取时间。可打开来源查看最新排名。'
      : '网站发布时及计划每6小时采集一次；实际更新受来源、任务执行和发布状态影响。';
  } catch {
    if (!rankingData && window.RANKING_SNAPSHOT) rankingData = {...window.RANKING_SNAPSHOT, stale:true};
    paintRankings();
    const error = document.querySelector('#ranking-error');
    if (error) error.textContent = '无法读取最新快照，保留已标明获取时间的资料。可打开来源完整榜单。';
  } finally {
    const current = document.querySelector('#ranking-refresh');
    if (current) { current.disabled = false; current.textContent = '↻ 检查最新快照'; }
  }
};
const pagesRankingsPage = rankingsPage;
rankingsPage = function () {
  pagesRankingsPage();
  for (const note of document.querySelectorAll('.notice')) {
    if (note.textContent.startsWith('页面打开时联网获取')) note.textContent = '榜单以定时采集快照展示，保留来源口径和真实获取时间。刷新按钮检查网站最新快照；点击原发布页可查看发行方介绍、宣传截图和视频。';
  }
};
